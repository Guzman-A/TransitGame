# TransitGame
A puzzle game building transitlines while dealing with the challenges of global warming.

Game Instructions:

Objective: Connect all city hubs by end of game (turn 16). In order to win, all
hubs must be connected on last turn.

How it Works: Transitlines cost money to build but return value (income) if city hubs are connected.
Transitlines also produce Co2. Different types of transit produce more Co2 than others.
Co2 is accumulative and will increase likelihood of a natural disaster occurring.
Natural disasters will destroy some transitlines.

Authors: Emily Segroves & Arturo Guzman
